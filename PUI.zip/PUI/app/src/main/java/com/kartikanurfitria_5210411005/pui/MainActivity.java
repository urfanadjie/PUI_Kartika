package com.kartikanurfitria_5210411005.pui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView fiturkalkulatormbi, fituraturberat, imageview6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        fiturkalkulatormbi = (ImageView) findViewById(R.id.fiturkalkulatormbi);
        fituraturberat = (ImageView) findViewById(R.id.fituraturberat);
        imageview6 = (ImageView) findViewById(R.id.imageview6);


        fiturkalkulatormbi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent bukakalkulatorbmi = new Intent(MainActivity.this, Kalkulatorbmi.class);
                startActivity(bukakalkulatorbmi);
            }
        });

        fituraturberat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent I = new Intent(MainActivity.this, Aturberatbadan.class);
                startActivity(I);
            }
        });

//        fituraturberat.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent a = new Intent(MainActivity.this, Olahraga.class);
//                startActivity(a);
//            }
//        });

    }
}